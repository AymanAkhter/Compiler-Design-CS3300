package visitor;
import syntaxtree.*;
import java.util.*;

public class Collector{
    public Map<Integer,Instruction> instrMap;
    public Map<String,Integer> labelMap;
}