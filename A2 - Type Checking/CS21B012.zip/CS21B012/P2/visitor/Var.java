package visitor;
import syntaxtree.*;
import java.util.*;

public class Var{
      public String name;
      public String type;
      public Var(String inname, String intype){
         name = inname;
         type = intype;
      }
   }