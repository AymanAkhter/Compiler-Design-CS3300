package visitor;
import syntaxtree.*;
import java.util.*;

public class Class{
      public String name;
      public String parent;
      public ArrayList<Method> MethodList;
      public ArrayList<Var> FieldsList;
   }