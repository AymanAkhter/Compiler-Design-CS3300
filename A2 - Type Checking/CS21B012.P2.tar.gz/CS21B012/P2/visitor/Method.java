package visitor;
import syntaxtree.*;
import java.util.*;

public class Method{
      public String name;
      public ArrayList<Var> arguments;
      public ArrayList<Var> variables;
      public String returnType;
   }